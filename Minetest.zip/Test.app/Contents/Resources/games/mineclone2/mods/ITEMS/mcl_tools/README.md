This mod adds tools for MineClone 2.

## Credits

* `default_shears_cut.ogg:`
    * Author: SmartWentCody (CC BY 3.0)
    * Source: <https://freesound.org/people/SmartWentCody/sounds/179015/>

Other files:
See main MineClone 2 README.
