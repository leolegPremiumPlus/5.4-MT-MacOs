## Extra fences
This mod adds a few extra fences to MCL2.

## Licensing
The sound files

    mcl_fences_nether_brick_fence_gate_open.ogg

and

    mcl_fences_nether_brick_fence_gate_close.ogg

were derived from sounds made by Freesound.org user Slanesh.
The license is CC BY 3.0 <https://creativecommons.org/licenses/by/3.0/>.

Source: <https://www.freesound.org/people/Slanesh/sounds/31770/>

Everything else is under the MIT License.
