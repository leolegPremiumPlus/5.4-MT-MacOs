This mod is originally by Zeg9, but heavily modified for MineClone 2.

Model created by 22i, licensed under the
GNU GPLv3 <https://www.gnu.org/licenses/gpl-3.0.html>.

Source: <https://github.com/22i/amc>
