Mesecons button mod.
This mod adds the buttons for MineClone 2.

MEDIA FILE CREDITS:

`mesecons_button_push.ogg`
    * Author: junggle <http://jazzy.junggle.net/>
    * License: CC BY 3.0 <http://creativecommons.org/licenses/by/3.0/>
    * Original name: `btn121.ogg`, created on January 16th, 2007
    * Source: <https://freesound.org/people/junggle/sounds/29301/>
`mesecons_button_push_wood.ogg`
    * Author: junggle <http://jazzy.junggle.net/>
    * License: (CC BY 3.0 <http://creativecommons.org/licenses/by/3.0/>
    * Original name: `btn314.ogg`, created on January 16th, 2007
    * Sound file was modified
    * Source: <https://freesound.org/people/junggle/sounds/29494/>
