This mod adds cocoas.
Cocoas grow at jungle trees in 3 stages and can be harvested for cocoa beans.
Cocoa beans can be used to plant new cocoas at jungle trees.

Partially based on the cocoas from Farming Redo by TenPlus1.
