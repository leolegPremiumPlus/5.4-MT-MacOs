This mod adds levers.

# Credits
## Mesh
Lever meshes created by Gerold55.

## Code
Jeija and Wuzzy.

## Textures
(See main README file of MineClone 2).
