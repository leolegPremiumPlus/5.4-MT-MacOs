# Hoppers
This is the Hoppers mod for Minetest. It's just a clone of Minecraft hoppers, functions nearly identical to them minus mesecons making them stop and the way they're placed.

## Forum Topic
- https://forum.minetest.net/viewtopic.php?f=11&t=12379
