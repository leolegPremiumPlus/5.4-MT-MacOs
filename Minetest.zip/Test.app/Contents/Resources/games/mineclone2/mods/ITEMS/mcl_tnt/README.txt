=== TNT mod for Minetest ===
by PilzAdam. HEAVILY modified for MineClone 2.

Introduction:
This mod adds TNT. TNT is a tool to help the player in mining.

How to use the mod:
There are different ways to blow up TNT:
1. Hit it with flint and steel.
2. Activate it with redstone circuits
Be aware of the damage radius!

License of mod code and media:
MIT License

Sound credits:

* tnt_explode.ogg: Jose Ortiz 'MindChamber' (CC0)
* tnt_ignite.ogg: Own derivate work of sound by Ned Bouhalassa (CC0) created in 2005, source: <https://freesound.org/people/Ned Bouhalassa/sounds/8320/>
