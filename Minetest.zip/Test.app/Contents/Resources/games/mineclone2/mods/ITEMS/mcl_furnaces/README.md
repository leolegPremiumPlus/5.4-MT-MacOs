Furnaces for MineClone 2.
Heavily based on Minetest Game (default/furnace.lua).

License of source code
----------------------
LGPLv2.1
Based on code from Minetest Game.
Modified by Wuzzy.

License of media
----------------
See the main MineClone 2 README.md file.
