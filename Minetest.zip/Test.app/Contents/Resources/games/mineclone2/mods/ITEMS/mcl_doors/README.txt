License of source code:
-----------------------
Copyright (C) 2012 PilzAdam
modified by BlockMen (added sounds, glassdoor, trapdoor)

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the Do What The Fuck You Want
To Public License, Version 2, as published by Sam Hocevar. See
http://sam.zoy.org/wtfpl/COPYING for more details.


License of sounds
--------------------------------------
Opening-Sound created by CGEffex (CC BY 3.0), modified by BlockMen
  doors_door_open.ogg
Closing-Sound created by bennstir (CC BY 3.0)
  doors_door_close.ogg
Steel door sounds open & close (CC-BY-3.0) by HazMatt
  - http://www.freesound.org/people/HazMattt/sounds/187283/
  doors_steel_door_open.ogg
  doors_steel_door_close.ogg

License/authors of texture files
--------------------------------------
Same as media license for MineClone 2 (see root directory).

With modifications by GitHub user kingoscargames:
- `doors_item_steel.png`
- `mcl_doors_door_iron_lower.png`
- `mcl_doors_door_iron_upper.png`
- `mcl_doors_trapdoor_acaica.png`
- `mcl_doors_trapdoor_birch.png`
- `mcl_doors_trapdoor_spruce.png`
- `mcl_doors_trapdoor_dark_oak.png`
- `mcl_doors_trapdoor_jungle.png`
