License information:

* Code: MIT License
* Textures: See main MineClone 2 README.md file
* Sounds: CC0
