MineClone 2 core mod
====================
Originally forked from Minetest Game's default mod in the distant past.

License information
===================

License of source code:
-----------------------
Copyright (C) 2011-2012 celeron55, Perttu Ahola <celeron55@gmail.com>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or
(at your option) any later version.

License of all textures and sounds
----------------------------------
MIT License.

The textures are taken from the Minecraft resource pack “Faithful 1.11” by Vattic and
xMrVizzy and contributers.

Sounds
======
All sounds included in this mod are under the MIT License.
The other sounds used in this mod can be found in CORE/mcl_sounds.

http://www.gnu.org/licenses/lgpl-2.1.html

License of everything not listed here
-------------------------------------
celeron55, Perttu Ahola <celeron55@gmail.com>
CC BY-SA 3.0 <https://creativecommons.org/licenses/by-sa/3.0/>


