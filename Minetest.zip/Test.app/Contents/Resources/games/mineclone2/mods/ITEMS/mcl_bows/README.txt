This mod adds bows and arrows for MineClone 2.

License:
* Source code: LGPL 3.0
    * Incorporates code from the [bow] mod by Arcelmi.
      https://github.com/Arcelmi/minetest-bows

* Textures: See MineClone 2 license notes.
* Sounds:
    * mcl_bows_bow_shoot.ogg: CC0 by Freesound.org user JoeDinesSound
      https://freesound.org/people/JoeDinesSound/sounds/534942/
    * mcl_bows_hit_other.ogg: CC0 by Freesound.org user JoeDinesSound
      https://freesound.org/people/JoeDinesSound/sounds/534952/
    * mcl_bows_hit_player.ogg: CC BY 3.0 by Freesound.org user tim.kahn.
      https://freesound.org/people/tim.kahn/sounds/38495/
      http://creativecommons.org/licenses/by/3.0/
