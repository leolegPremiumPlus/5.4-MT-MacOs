This mod adds small and huge mushrooms. Small mushrooms like to spread in darkness.
