Mod based on reworked signs mod by PilzAdam:
https://forum.minetest.net/viewtopic.php?t=3289

License of code and font: MIT License

Font source: 04.jp.org, some modifications and additions were made (added support for Latin-1 Supplement)
Original font license text states: “YOU MAY USE THEM AS YOU LIKE” (in about.gif file distributed with the font)

License of textures: See README.md in top directory of MineClone 2.

License of models: GPLv3 (https://www.gnu.org/licenses/gpl-3.0.html)
Models author: 22i.
Source: https://github.com/22i/amc
