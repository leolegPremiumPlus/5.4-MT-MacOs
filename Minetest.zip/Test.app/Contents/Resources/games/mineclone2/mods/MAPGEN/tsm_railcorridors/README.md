# Railway corridors [`tsm_railcorridors`]
MineClone 2 adaption. NO TREASURER SUPPORT!

* Current version 0.14.0

Minetest mod for adding underground corridors with rails and wood constructions with a few treasure chests now and then.
Optional support for the Treasurer mod is available for adding treasures from various mods.
Cobwebs are added if the `mobs_monster` mod is found.

Use the advanced settings to finetune the railway corridors.

* Forum thread: https://forum.minetest.net/viewtopic.php?t=10339
* License: MIT License.

## Info for game makers
Want to include this mod in a game, but you have problems with the dependencies?
Edit `gameconfig.lua` to fit your needs. :-)
