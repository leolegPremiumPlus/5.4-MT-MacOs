# Biome Info API [`biomeinfo`]
This is an API mod for mod developers to add a couple of missing
biome-related functions.
Currently, this mod only adds v6-related functions.
Most importantly, you can get the heat, humidity and biome in the v6 mapgen.

See `API.md` for the API documentation.

Current version: 1.0.3 (this is a [SemVer](https://semver.org/))

License: MIT License
